Description:
	Guess the number game

Linux:
	run compile.sh to compile it

FreeDOS:
